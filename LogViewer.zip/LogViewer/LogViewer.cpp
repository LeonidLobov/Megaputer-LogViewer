#include "LogViewer.h"

LogViewer::LogViewer() {
	hFile = INVALID_HANDLE_VALUE;
	sFilter = NULL;
	pLastSymbol = NULL;
	hMap = NULL;
	pView = NULL;
	pLine = NULL;
	pSymbol = NULL;
	pEOF = NULL;
}

LogViewer::~LogViewer() {
	if(!Close())
		SetLastError(ERROR_FAIL_SHUTDOWN);
}

BOOL LogViewer::Open(LPCSTR sFileName) {
	BOOL bResult = hFile == INVALID_HANDLE_VALUE;

	if (!bResult)
		bResult = Close();
	if (bResult) {
		hFile = CreateFile(sFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_NO_BUFFERING, NULL);
		bResult = hFile != INVALID_HANDLE_VALUE;
		if (bResult) {
			hMap = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0UL, 0UL, NULL);
			bResult = hMap != NULL;
			if (bResult) {
				pView = (LPCSTR) MapViewOfFile(hMap, FILE_MAP_READ, 0UL, 0UL, 0UL);
				bResult = pView != NULL;
				if (bResult) {
					DWORD dwFileSizeHigh = 0UL;
					pEOF = pView + GetFileSize(hFile, &dwFileSizeHigh);
					bResult = pEOF > pView && !dwFileSizeHigh;
					if (!bResult)
						SetLastError(ERROR_FILE_TOO_LARGE);
				}
			}
		}
	}
	
	return bResult;
}

BOOL LogViewer::Close() {
	BOOL bResult = TRUE;

	if (pSymbol)
		pSymbol = NULL;
	if (pLine)
		pLine = NULL;
	if (pEOF)
		pEOF = NULL;
	if (pView) {
		bResult = UnmapViewOfFile((LPCVOID)pView);
		pView = NULL;
	}
	if (hMap) {
		bResult = CloseHandle(hMap);
		hMap = NULL;
	}
	if (pLastSymbol)
		pLastSymbol = NULL;
	if (sFilter) {
		delete[] sFilter;
		sFilter = NULL;
	}
	if (hFile != INVALID_HANDLE_VALUE) {
		bResult = CloseHandle(hFile);
		hFile = INVALID_HANDLE_VALUE;
	}

	return bResult;
}

VOID LogViewer::SetFilter(LPCSTR sFilter) {
	pSymbol = pView;
	pLine = NULL;
	if (pLastSymbol)
		pLastSymbol = NULL;
	if (this->sFilter)
		delete[] this->sFilter;
	if (!sFilter)
		this->sFilter = NULL;
	else {
		DWORD dwSize = strlen(sFilter);
		if (dwSize < 1)
			this->sFilter = NULL;
		else {
			this->sFilter = new CHAR[dwSize + 1];
			this->sFilter[0] = *sFilter;
			DWORD j = 0UL;
			for (DWORD i = 1UL; i < dwSize; i++)
				if (*(this->sFilter + j) == ANY_STRING)
					if(*(sFilter + i) == ANY_STRING)
						continue;
					else if (*(sFilter + i) == ANY_SYMBOL) {
						this->sFilter[j++] = ANY_SYMBOL;
						this->sFilter[j] = ANY_STRING;
					} else
						this->sFilter[++j] = sFilter[i];
				else
					this->sFilter[++j] = sFilter[i];
			if (!j && *this->sFilter == ANY_STRING) {
				delete[] this->sFilter;
				this->sFilter = NULL;
			} else {
				pLastSymbol = this->sFilter + ++j;
				this->sFilter[j] = END_OF_STRING;
			}
		}
	}
}

LPCSTR LogViewer::GetNextLine(int* linesize) {
	if (!pSymbol || !*pSymbol)
		return NULL;
	pLine = pSymbol;
	if (!sFilter || IsFound()) {
		MoveToNextLine();
		*linesize = pSymbol - pLine;
	} else {
		*linesize = 0;
		pLine = NULL;
	}

	return pLine;
}

inline BOOL LogViewer::IsFound() {
	while (pSymbol < pEOF)
		if (IsEqual())
			return TRUE;
		else
			pSymbol++;

	return FALSE;
}

inline BOOL LogViewer::IsEqual() {
	LPCSTR pSymbol = this->pSymbol, pFS = sFilter;

	if(*pSymbol == END_OF_STRING)
		return FALSE;
	else if (*pSymbol == CR)
		pLine = pSymbol += 2;
	else if (*pSymbol == LF)
		pLine = ++pSymbol;
	if (*pFS != ANY_STRING && *pFS != ANY_SYMBOL && *pFS != *pSymbol)
		return FALSE;
	else
		pSymbol++;
	for (++pFS; pFS < pLastSymbol; pFS++)
		if (pSymbol == pEOF || *pSymbol == CR || *pSymbol == LF || *pSymbol == END_OF_STRING)
			return FALSE;
		else if (*pFS == ANY_STRING)
			continue;
		else if (*pFS == ANY_SYMBOL || *pFS == *pSymbol)
			pSymbol++;
		else if (*(pFS - 1UL) != ANY_STRING)
			return FALSE;
		else
			while (++pSymbol < pEOF && *pFS ^ *(pSymbol))
				if (*pSymbol == CR || *pSymbol == LF || *pSymbol == END_OF_STRING)
					return FALSE;
	this->pSymbol = pSymbol;

	return TRUE;
}

inline VOID LogViewer::MoveToNextLine() {
	while (pSymbol < pEOF && *pSymbol ^ END_OF_STRING)
		if (*pSymbol++ == LF)
			return;
}