#include "LogViewer.h"

int main(int argc, char* argv[])
{
	int iExitCode = ERROR_SUCCESS;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	
	if (hConsole == INVALID_HANDLE_VALUE)
		iExitCode = ERROR_INVALID_HANDLE;
	else if (argc < 2)
		iExitCode = ERROR_NO_DATA;
	else {
		LogViewer lv;
		if (!lv.Open(argv[1]))
			iExitCode = ERROR_FILE_NOT_FOUND;
		else {
			if (argc > 2)
				lv.SetFilter(argv[2]);
			if(argc > 3)
				if (!SetConsoleOutputCP((UINT) atoi(argv[3])))
					iExitCode = ERROR_BAD_ARGUMENTS;
			LPCSTR sOutput = NULL;
			DWORD dwBytesRead = 0UL, dwBytesWritten = 0UL;
			do {
				sOutput = lv.GetNextLine((int*) &dwBytesRead);
				if (sOutput == NULL || dwBytesRead == 0UL)
					break;
				if (!WriteConsole(hConsole, sOutput, dwBytesRead, &dwBytesWritten, NULL))
					break;
			} while (dwBytesWritten != 0UL);
			iExitCode = GetLastError();
			if (!lv.Close())
				iExitCode = GetLastError();
		}
		if (!CloseHandle(hConsole))
			iExitCode = GetLastError();
		hConsole = INVALID_HANDLE_VALUE;
	}
	
	return iExitCode;
}